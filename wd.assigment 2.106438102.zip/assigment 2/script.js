window.onload = function () {
    updateDeposit();
    prefillRestaurant();

    const registerForm = document.getElementById("registerForm");
    if (registerForm) {
        registerForm.addEventListener("submit", validateRegisterForm);
    }

    const reservationForm = document.getElementById("reservationForm");
    if (reservationForm) {
        reservationForm.addEventListener("submit", validateReservationForm);
    }

    const sameEmail = document.getElementById("sameEmail");
    if (sameEmail) {
        sameEmail.addEventListener("change", copyEmail);
    }
};

function validateRegisterForm(event) {
    let errors = [];

    const username = document.getElementById("username").value;
    const email = document.getElementById("email").value;
    const phone = document.getElementById("phone").value;
    const password = document.getElementById("password").value;
    const confirmPassword = document.getElementById("confirmPassword").value;
    const gender = document.getElementById("gender").value;

    const usernameRegex = /^\w{5,}$/;
    const emailRegex = /^[^ ]+@[^ ]+\.[a-z]{2,3}$/;
    const phoneRegex = /^\d{8,15}$/;
    const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&]).{10,}$/;

    if (!usernameRegex.test(username)) {
        errors.push("Username must contain at least 5 characters and only letters, numbers and underscores.");
    }

    if (!emailRegex.test(email)) {
        errors.push("Please enter a valid email address.");
    }

    if (!phoneRegex.test(phone)) {
        errors.push("Phone number must contain 8-15 digits.");
    }

    if (!passwordRegex.test(password)) {
        errors.push("Password must contain uppercase, lowercase, number and special character.");
    }

    if (password !== confirmPassword) {
        errors.push("Passwords do not match.");
    }

    if (gender === "") {
        errors.push("Please select a gender.");
    }

    if (errors.length > 0) {
        event.preventDefault();
        document.getElementById("registerErrors").innerHTML = errors.join("<br>");
    }
}

function validateReservationForm(event) {
    let errors = [];

    const email = document.getElementById("resEmail").value;
    const phone = document.getElementById("resPhone").value;
    const date = document.getElementById("date").value;
    const people = document.getElementById("people").value;
    const paymentMethod = document.getElementById("paymentMethod").value;
    const card = document.getElementById("card").value;

    const today = new Date().toISOString().split("T")[0];

    if (date < today) {
        errors.push("Reservation date cannot be in the past.");
    }

    if (people <= 0) {
        errors.push("Number of people must be greater than 0.");
    }

    if (phone.length < 10) {
        errors.push("Phone number must contain at least 10 digits.");
    }

    if (paymentMethod === "Online") {
        if (!(card.length === 15 || card.length === 16)) {
            errors.push("Credit card must contain 15 or 16 digits.");
        }
    }

    if (errors.length > 0) {
        event.preventDefault();
        document.getElementById("reservationErrors").innerHTML = errors.join("<br>");
    }
}

function recommendRestaurant() {
    const diet = document.getElementById("diet").value;
    const budget = document.getElementById("budget").value;
    const purpose = document.getElementById("purpose").value;

    let recommendation = "Burger Hub";

    if (diet === "Vegan") {
        recommendation = "Green Leaf";
    }
    else if (diet === "Halal") {
        recommendation = "Spice Garden";
    }
    else if (budget === "High" && purpose === "Date") {
        recommendation = "Ocean Grill";
    }
    else if (purpose === "Business") {
        recommendation = "Sakura";
    }
    else if (purpose === "Family") {
        recommendation = "Bella Roma";
    }

    document.getElementById("recommendationResult").innerHTML =
        `<h3>Recommended Restaurant: ${recommendation}</h3>
         <a class="btn" href="reservation.html?restaurant=${recommendation}">Reserve Now</a>`;
}

function updateDeposit() {
    const restaurant = document.getElementById("restaurant");

    if (!restaurant) {
        return;
    }

    const depositField = document.getElementById("deposit");

    const deposits = {
        "Bella Roma": "$25",
        "Sakura": "$20",
        "Spice Garden": "$15",
        "Green Leaf": "$10",
        "Ocean Grill": "$35",
        "Burger Hub": "$12"
    };

    depositField.value = deposits[restaurant.value];
}

function togglePaymentFields() {
    const paymentMethod = document.getElementById("paymentMethod").value;

    const voucherSection = document.getElementById("voucherSection");
    const cardSection = document.getElementById("cardSection");

    if (paymentMethod === "Voucher") {
        voucherSection.style.display = "block";
        cardSection.style.display = "none";
    }
    else {
        voucherSection.style.display = "none";
        cardSection.style.display = "block";
    }
    }

function copyEmail() {
    const sameEmail = document.getElementById("sameEmail");

    if (sameEmail.checked) {
        document.getElementById("billingEmail").value =
            document.getElementById("resEmail").value;
    }
}

function prefillRestaurant() {
    const params = new URLSearchParams(window.location.search);
    const restaurant = params.get("restaurant");

    if (restaurant && document.getElementById("restaurant")) {
        document.getElementById("restaurant").value = restaurant;
        updateDeposit();
    }
}

function calculateBill() {
    const avgPrice = document.getElementById("avgPrice").value;
    const groupSize = document.getElementById("groupSize").value;

    const total = avgPrice * groupSize;

    document.getElementById("billResult").innerHTML =
        `Estimated Total: $${total}`;
}