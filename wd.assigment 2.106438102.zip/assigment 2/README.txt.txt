README.txt

DineFind Restaurant Discovery Platform

Website Structure:
- index.html = Home page
- restaurants.html = Restaurant listings
- recommend.html = Recommendation page
- register.html = Registration form
- reservation.html = Reservation form
- bill.html = Bonus bill calculator
- css/style.css = Styling and responsive design
- js/script.js = JavaScript validation and dynamic functionality

GitHub Repository Link:
https://github.com/yourusername/dinefind

JavaScript Validation Logic:
- Registration form validates username, email, phone number and password.
- Reservation form validates reservation date, payment method and credit card length.
- Recommendation page uses rule-based logic to suggest restaurants.
- Deposit amount updates dynamically depending on selected restaurant.
- Payment sections change dynamically depending on payment method.

Known Issues:
- Credit card processing is simulated only.
- No backend database is connected.

References:
- https://www.w3schools.com
- https://developer.mozilla.org
- Restaurant images sourced from Unsplash.